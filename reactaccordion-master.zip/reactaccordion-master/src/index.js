import React from 'react';
import ReactDOM from 'react-dom';
import Accordion from './app';



ReactDOM.render(<Accordion/>,document.getElementById('root'))