const all = [
    {
        question: "What is react?",
        answer:
            "React is a JavaScript library used to build views which is mainly concentrated on the view part in the MVC model."
    },
    {
        question: "What is JSX ?",
        answer:
            "JSX is JavaScript Xml which is used inside the react to write the html like syntax inside the javascript it’s just a abstraction.The jsx we write later converts into the JavaScript with the help of babel."
    },
    {
        question: "What is Nodejs  ?",
        answer:
            "Nodejs is a backend JavaScript framework built on top of v8 JavaScript engine."
    },
    {
        question: "What is npm ?",
        answer:
            "npm is a node package manager which is used to install the libraries created by the other people.By using npm you can install or uninstall packages at any point of time."
    }
];

export default all;
