# React Accordion


Full tutorial is on [reactgo.com](https://reactgo.com)


### Install

```bash
git clone https://github.com/saigowthamr/reactaccordion.git
```

Then you can run it by:

```bash
cd reactaccordion
npm install
npm start
```
